﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeSortPerso
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] nums = { 5, -1, 23, 13, 42, 73, 25, -7, 28, 61 };
            MergeSort(nums);
            Print(nums);
        }

        public static void Print(int[] arr)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                Console.Write(arr[i] + " ");
            }
            Console.ReadLine();
        }

        public static void MergeSort(int[] arr)
        {
            int[] tmp = new int[arr.Length];
            MergeSortHelper(arr, 0, arr.Length - 1, tmp);
        }

        public static void MergeSortHelper(int[] arr, int start, int end, int[] tmp)
        {
            if ((end - start) >= 1)
            {
                int middle = (start + end) / 2;
                MergeSortHelper(arr, start, middle, tmp);
                MergeSortHelper(arr, middle + 1, end, tmp);
                Merge(arr, start, middle, end, tmp);
            }           
        }

        public static void Merge(int[] arr, int start, int middle, int end, int[] tmp)
        {
            int i = start;
            int j = middle +1;
            int k = i;
            while (i <= middle && j <= end)
            {
                if (arr[i] <= arr[j])
                {
                    tmp[k] = arr[i];
                    i++;
                    k++;
                }
               
                else
                {
                    tmp[k] = arr[j];
                    j++;
                    k++;
                }
            }

            while (i <= middle)
            {
                tmp[k] = arr[i];
                i++;
                k++;
            }

            while (j <= end)
            {
                tmp[k] = arr[j];
                j++;
                k++;
            }

            //push the value in the arr
            for( k = start; k <= end; k++)
            {
                arr[k] = tmp[k];
            }  
        }
    }
}
